echo Pushing...
git add --all :/
git commit -m "GitHelper Push"
git push
