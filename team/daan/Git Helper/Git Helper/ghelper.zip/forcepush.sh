echo You have been warned...
git add --all :/
git commit -m "Force Push GitHelper"
git forcepush