echo Signin
git add --all :/
git commit -m "GitHelper Github Login"
git push
